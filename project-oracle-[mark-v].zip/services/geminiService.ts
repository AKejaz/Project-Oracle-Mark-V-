import { GoogleGenAI, Type } from "@google/genai";
import { AnalyzedData, MarketSignal, SignalType, NewsItem, TickerContext } from '../types';

const getAIClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) throw new Error("API Key missing");
  return new GoogleGenAI({ apiKey });
};

// --- LAYER 1: REAL-TIME SEARCH GROUNDING & CONTEXT ---

export const fetchTickerContext = async (ticker: string): Promise<TickerContext> => {
  try {
    const ai = getAIClient();
    // We explicitly ask for the price 30 days ago to anchor our simulation
    const prompt = `
      I need real-time financial data for: ${ticker}.
      1. Current Price
      2. Price roughly 30 days ago (for trend calculation)
      3. Percent change today
      4. Company Name, Sector, and Market Cap.
      
      If it's a Pakistan stock (PSX), look up the correct KSE/PSX data.
      Return strictly valid JSON.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            price: { type: Type.NUMBER },
            price30DaysAgo: { type: Type.NUMBER },
            changePercent: { type: Type.NUMBER },
            companyName: { type: Type.STRING },
            sector: { type: Type.STRING },
            marketCap: { type: Type.STRING },
            currency: { type: Type.STRING }
          },
          required: ["price", "price30DaysAgo", "changePercent", "companyName"]
        }
      }
    });

    const data = JSON.parse(response.text || '{}');
    
    // Fallback if search fails
    if (!data.price) {
      const fallbackPrice = ticker.includes('BTC') ? 90000 : 150;
      return {
        price: fallbackPrice,
        price30DaysAgo: fallbackPrice * 0.95, // Assume slight uptrend default
        changePercent: 0,
        companyName: ticker,
        sector: "Unknown",
        marketCap: "N/A",
        currency: 'USD'
      };
    }

    return {
      price: data.price,
      price30DaysAgo: data.price30DaysAgo || data.price * 0.95, // Fallback if history missing
      changePercent: data.changePercent,
      companyName: data.companyName,
      sector: data.sector || "Tech",
      marketCap: data.marketCap || "N/A",
      currency: data.currency || 'USD'
    };

  } catch (error) {
    console.error("Context Fetch Failed:", error);
    return {
      price: 150.00,
      price30DaysAgo: 145.00,
      changePercent: 0.5,
      companyName: ticker,
      sector: "System Error",
      marketCap: "N/A",
      currency: 'USD'
    };
  }
};

export const fetchGlobalIntel = async (ticker: string): Promise<NewsItem[]> => {
  try {
    const ai = getAIClient();
    const prompt = `
      Find 3 recent financial news headlines for ${ticker}.
      Analyze the sentiment of each headline as 'positive', 'negative', or 'neutral'.
      Return JSON.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        tools: [{ googleSearch: {} }],
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              source: { type: Type.STRING },
              sentiment: { type: Type.STRING, enum: ['positive', 'negative', 'neutral'] },
              url: { type: Type.STRING }
            }
          }
        }
      }
    });

    const news = JSON.parse(response.text || '[]');
    return news;
  } catch (error) {
    console.error("Intel Fetch Failed:", error);
    return [];
  }
};

export const analyzeWithOracle = async (ticker: string, data: AnalyzedData): Promise<{ summary: string, signal: MarketSignal }> => {
  try {
    const ai = getAIClient();
    const latest = data;
    
    const prompt = `
      You are PROJECT ORACLE, a precision trading AI. Analyze ${ticker}.
      
      TECHNICAL DATA:
      Current Price: ${latest.close}
      RSI (14): ${latest.indicators.rsi.toFixed(2)}
      MACD Histogram: ${latest.indicators.macd.histogram.toFixed(4)}
      Bollinger Band Position: ${latest.close > latest.indicators.bollinger.upper ? "ABOVE UPPER BAND (Overbought)" : latest.close < latest.indicators.bollinger.lower ? "BELOW LOWER BAND (Oversold)" : "WITHIN BANDS"}
      EMA50: ${latest.indicators.ema50.toFixed(2)}
      
      TASK:
      1. Determine the Signal (BUY/SELL/WAIT).
      2. Calculate specific trade levels: 
         - Entry Zone (Where to buy/short)
         - Stop Loss (Invalidation point)
         - Target Price (Take Profit)
      3. Assess Risk Level based on volatility and RSI.
      
      Output strictly valid JSON.
    `;

    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            signal: { type: Type.STRING, enum: ["BUY", "SELL", "WAIT"] },
            score: { type: Type.NUMBER, description: "Confidence score 0-100" },
            summary: { type: Type.STRING },
            reasoning: { type: Type.ARRAY, items: { type: Type.STRING } },
            entryZone: { type: Type.STRING, description: "e.g. $145.50 - $146.00" },
            stopLoss: { type: Type.STRING, description: "Specific price" },
            targetPrice: { type: Type.STRING, description: "Specific price" },
            riskLevel: { type: Type.STRING, enum: ["LOW", "MEDIUM", "HIGH", "EXTREME"] }
          },
          required: ["signal", "score", "summary", "entryZone", "stopLoss", "targetPrice", "riskLevel"]
        }
      }
    });

    const result = JSON.parse(response.text || '{}');
    return {
      summary: result.summary,
      signal: {
        type: result.signal as SignalType,
        score: result.score,
        reasoning: result.reasoning || [],
        entryZone: result.entryZone || "MARKET",
        stopLoss: result.stopLoss || "N/A",
        targetPrice: result.targetPrice || "N/A",
        riskLevel: (result.riskLevel as any) || "MEDIUM"
      }
    };

  } catch (error) {
    console.error("Analysis Failed", error);
    return {
      summary: "DATA CORRUPTION DETECTED. ANALYSIS ABORTED.",
      signal: { 
        type: SignalType.WAIT, 
        score: 0, 
        reasoning: ["Oracle Unresponsive"],
        entryZone: "---",
        stopLoss: "---",
        targetPrice: "---",
        riskLevel: "HIGH"
      }
    };
  }
};
