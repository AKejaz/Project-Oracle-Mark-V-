import { AnalyzedData, StockData, Indicators } from '../types';

// --- MATH ENGINE (Technical Indicators) ---

const calculateRSI = (prices: number[], period: number = 14): number => {
  if (prices.length < period + 1) return 50;
  
  let gains = 0;
  let losses = 0;

  for (let i = prices.length - period; i < prices.length; i++) {
    const diff = prices[i] - prices[i - 1];
    if (diff >= 0) gains += diff;
    else losses += Math.abs(diff);
  }

  const avgGain = gains / period;
  const avgLoss = losses / period;

  if (avgLoss === 0) return 100;
  const rs = avgGain / avgLoss;
  return 100 - (100 / (1 + rs));
};

const calculateEMA = (prices: number[], period: number): number => {
  if (prices.length < period) return prices[prices.length - 1];
  const k = 2 / (period + 1);
  let ema = prices[0];
  for (let i = 1; i < prices.length; i++) {
    ema = prices[i] * k + ema * (1 - k);
  }
  return ema;
};

const calculateMACD = (prices: number[]): { macdLine: number; signalLine: number; histogram: number } => {
  const shortPeriod = 12;
  const longPeriod = 26;
  const signalPeriod = 9;

  if (prices.length < longPeriod) return { macdLine: 0, signalLine: 0, histogram: 0 };

  const ema12 = calculateEMA(prices.slice(-shortPeriod * 2), shortPeriod);
  const ema26 = calculateEMA(prices.slice(-longPeriod * 2), longPeriod);
  
  const macdLine = ema12 - ema26;
  const signalLine = macdLine * 0.9; // Simplified approximation
  const histogram = macdLine - signalLine;

  return { macdLine, signalLine, histogram };
};

const calculateBollinger = (prices: number[], period: number = 20): { upper: number; middle: number; lower: number } => {
  if (prices.length < period) return { upper: 0, middle: 0, lower: 0 };
  
  const slice = prices.slice(-period);
  const mean = slice.reduce((a, b) => a + b, 0) / period;
  const variance = slice.reduce((a, b) => a + Math.pow(b - mean, 2), 0) / period;
  const stdDev = Math.sqrt(variance);

  return {
    upper: mean + (stdDev * 2),
    middle: mean,
    lower: mean - (stdDev * 2)
  };
};

// --- BROWNIAN BRIDGE GENERATOR ---
// This ensures the simulated chart connects Point A (30 days ago) to Point B (Today)
// making the trend visual accurate to real world data.

export const generateCalibratedData = (currentPrice: number, price30DaysAgo: number, volatility: number = 0.02): AnalyzedData[] => {
  const days = 30; // 30 trading days roughly
  const data: StockData[] = [];
  const prices: number[] = new Array(days).fill(0);
  
  prices[0] = price30DaysAgo;
  prices[days - 1] = currentPrice;

  // Generate Brownian Bridge
  for (let i = 1; i < days - 1; i++) {
    const t = i / days;
    // Linear interpolation between start and end
    const mu = price30DaysAgo + (currentPrice - price30DaysAgo) * t;
    // Add noise (Bridge variance is t * (1-t))
    const sigma = volatility * currentPrice * Math.sqrt(t * (1 - t));
    const noise = (Math.random() - 0.5) * 2 * sigma;
    
    prices[i] = mu + noise;
  }
  // Force end to match exactly
  prices[days-1] = currentPrice;

  const now = new Date();

  for (let i = 0; i < days; i++) {
    const date = new Date(now);
    date.setDate(date.getDate() - (days - 1 - i));
    
    const price = prices[i];
    const range = price * (volatility * 0.3); // High/Low variance
    
    data.push({
      timestamp: date.toISOString().split('T')[0],
      open: price + (Math.random() - 0.5) * range,
      high: price + Math.random() * range,
      low: price - Math.random() * range,
      close: price,
      volume: Math.floor(Math.random() * 1000000) + 500000
    });
  }

  // Calculate Indicators
  const closingPrices = data.map(d => d.close);
  
  return data.map((d, index) => {
    const slice = closingPrices.slice(0, index + 1);
    return {
      ...d,
      indicators: {
        rsi: calculateRSI(slice),
        macd: calculateMACD(slice),
        bollinger: calculateBollinger(slice),
        ema50: calculateEMA(slice, 50)
      }
    };
  });
};
