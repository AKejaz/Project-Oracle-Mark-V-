import React, { useState } from 'react';
import { AnalyzedData, BacktestResult } from '../types';

interface StrategySimProps {
  data: AnalyzedData[];
}

export const StrategySim: React.FC<StrategySimProps> = ({ data }) => {
  const [rsiThreshold, setRsiThreshold] = useState(30);
  const [result, setResult] = useState<BacktestResult | null>(null);

  const runBacktest = () => {
    let cash = 10000;
    let holdings = 0;
    let trades = 0;
    let wins = 0;
    let entryPrice = 0;

    // Simple strategy: Buy if RSI < Threshold, Sell if RSI > 70
    data.forEach((day, i) => {
      if (i === 0) return;

      if (day.indicators.rsi < rsiThreshold && cash > 0) {
        // BUY
        holdings = cash / day.close;
        cash = 0;
        entryPrice = day.close;
        trades++;
      } else if (day.indicators.rsi > 70 && holdings > 0) {
        // SELL
        cash = holdings * day.close;
        if (day.close > entryPrice) wins++;
        holdings = 0;
        trades++;
      }
    });

    // Close final position
    let finalValue = cash;
    if (holdings > 0) {
       finalValue = holdings * data[data.length - 1].close;
    }

    setResult({
      trades,
      wins,
      totalReturn: ((finalValue - 10000) / 10000) * 100,
      winRate: trades > 0 ? (wins / (trades / 2)) * 100 : 0 // approx win rate per completed trade cycle
    });
  };

  return (
    <div className="h-full bg-[#050505] border border-[#111] p-6 flex flex-col gap-6">
      <div>
        <h2 className="text-[#00FF41] text-xl font-bold tracking-widest mb-2">STRATEGY SIMULATOR</h2>
        <p className="text-[#666] text-xs font-mono">BACKTEST ALGORITHMS ON CURRENT DATASET</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Controls */}
        <div className="space-y-6">
          <div className="bg-[#111] p-4 border border-[#333]">
            <label className="block text-xs text-[#00FF41] mb-2 font-bold">RSI BUY THRESHOLD: {rsiThreshold}</label>
            <input 
              type="range" 
              min="10" 
              max="50" 
              value={rsiThreshold} 
              onChange={(e) => setRsiThreshold(parseInt(e.target.value))}
              className="w-full accent-[#00FF41] h-1 bg-[#333] appearance-none cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-[#666] mt-1">
              <span>AGGRESSIVE (50)</span>
              <span>CONSERVATIVE (10)</span>
            </div>
          </div>

          <div className="bg-[#111] p-4 border border-[#333]">
            <div className="text-xs text-[#666] mb-2 font-bold">LOGIC KERNEL</div>
            <div className="font-mono text-xs text-gray-400 space-y-1">
              <p>IF <span className="text-blue-400">RSI</span> &lt; {rsiThreshold} THEN <span className="text-[#00FF41]">BUY</span></p>
              <p>IF <span className="text-blue-400">RSI</span> &gt; 70 THEN <span className="text-[#FF003C]">SELL</span></p>
            </div>
          </div>

          <button 
            onClick={runBacktest}
            className="w-full py-3 bg-[#00FF41] text-black font-bold tracking-widest hover:bg-[#00CC33] transition-colors"
          >
            EXECUTE BACKTEST
          </button>
        </div>

        {/* Results */}
        <div className="relative border border-[#333] bg-[#0a0a0a] p-6 flex flex-col justify-center items-center">
            {!result ? (
               <div className="text-[#333] text-sm animate-pulse">AWAITING EXECUTION...</div>
            ) : (
               <div className="w-full space-y-4">
                  <div className="flex justify-between items-end border-b border-[#333] pb-2">
                    <span className="text-[#666] text-xs">TOTAL RETURN</span>
                    <span className={`text-2xl font-bold ${result.totalReturn >= 0 ? 'text-[#00FF41]' : 'text-[#FF003C]'}`}>
                      {result.totalReturn > 0 ? '+' : ''}{result.totalReturn.toFixed(2)}%
                    </span>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                     <div>
                       <div className="text-[#666] text-[10px]">TRADES EXECUTED</div>
                       <div className="text-white font-mono">{result.trades}</div>
                     </div>
                     <div>
                       <div className="text-[#666] text-[10px]">WIN RATE</div>
                       <div className="text-white font-mono">{result.winRate.toFixed(1)}%</div>
                     </div>
                  </div>
               </div>
            )}
        </div>
      </div>
    </div>
  );
};
