import React from 'react';
import { AnalyzedData, MarketSignal, SignalType } from '../types';

interface SignalTerminalProps {
  signal: MarketSignal | null;
  data: AnalyzedData[]; // For technical matrix
  loading: boolean;
  onAnalyze: () => void;
}

export const SignalTerminal: React.FC<SignalTerminalProps> = ({ signal, data, loading, onAnalyze }) => {
  const latest = data[data.length - 1];

  // Helper to determine technical states purely from math (determinism)
  const getRSIState = (val: number) => val > 70 ? 'OVERBOUGHT' : val < 30 ? 'OVERSOLD' : 'NEUTRAL';
  const getMACDState = (hist: number) => hist > 0 ? 'BULLISH' : 'BEARISH';
  const getTrendState = (price: number, ema: number) => price > ema ? 'UPTREND' : 'DOWNTREND';

  if (loading) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-[#050505] border border-[#111]">
        <div className="relative w-24 h-24 mb-6">
           <div className="absolute inset-0 border-4 border-[#00FF41]/20 rounded-full animate-ping"></div>
           <div className="absolute inset-0 border-4 border-t-[#00FF41] rounded-full animate-spin"></div>
        </div>
        <div className="text-[#00FF41] font-mono text-xl tracking-[0.2em] animate-pulse">COMPUTING TRADE VECTORS...</div>
        <div className="text-[#666] text-xs mt-2">ANALYZING VOLATILITY MODELS // CHECKING RESISTANCE</div>
      </div>
    );
  }

  if (!signal || !latest) {
    return (
      <div className="h-full flex flex-col items-center justify-center bg-[#050505] border border-[#111]">
        <h2 className="text-[#666] font-mono mb-4">NO SIGNAL DATA AVAILABLE</h2>
        <button 
            onClick={onAnalyze}
            className="px-8 py-3 bg-[#111] text-[#00FF41] border border-[#00FF41] hover:bg-[#00FF41] hover:text-black transition-all font-bold tracking-widest uppercase neon-border"
          >
            INITIALIZE ORACLE
          </button>
      </div>
    );
  }

  const isBuy = signal.type === SignalType.BUY;
  const isSell = signal.type === SignalType.SELL;
  const mainColor = isBuy ? '#00FF41' : isSell ? '#FF003C' : '#FACC15';

  return (
    <div className="h-full bg-[#050505] p-6 overflow-y-auto">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-full">
        
        {/* COLUMN 1: THE SIGNAL */}
        <div className="flex flex-col gap-6">
          <div className="bg-[#0a0a0a] border border-[#333] p-6 relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-1 h-full" style={{ backgroundColor: mainColor }}></div>
            <h3 className="text-[#666] text-xs font-bold tracking-widest mb-2">PRIMARY DIRECTIVE</h3>
            <div className="text-6xl font-black tracking-tighter mb-2" style={{ color: mainColor, textShadow: `0 0 20px ${mainColor}40` }}>
              {signal.type}
            </div>
            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs text-gray-400">CONFIDENCE:</span>
              <div className="flex-1 h-2 bg-[#111] rounded-full">
                <div className="h-full rounded-full transition-all duration-1000" style={{ width: `${signal.score}%`, backgroundColor: mainColor }}></div>
              </div>
              <span className="text-xs font-bold text-white">{signal.score}%</span>
            </div>
            <div className={`inline-block px-3 py-1 rounded text-[10px] font-bold border ${
              signal.riskLevel === 'HIGH' || signal.riskLevel === 'EXTREME' ? 'border-red-500 text-red-500' : 'border-blue-500 text-blue-500'
            }`}>
              RISK LEVEL: {signal.riskLevel}
            </div>
          </div>

          <div className="bg-[#0a0a0a] border border-[#333] p-6 flex-1">
             <h3 className="text-[#666] text-xs font-bold tracking-widest mb-4">AI REASONING LOG</h3>
             <ul className="space-y-3">
               {signal.reasoning.map((reason, i) => (
                 <li key={i} className="flex gap-3 text-sm text-gray-300 font-mono">
                   <span style={{ color: mainColor }}>{'>'}</span>
                   {reason}
                 </li>
               ))}
             </ul>
          </div>
        </div>

        {/* COLUMN 2: TRADE SETUP */}
        <div className="flex flex-col gap-6">
           <div className="bg-[#0a0a0a] border border-[#333] p-6 h-full flex flex-col justify-center relative">
             <div className="absolute top-2 right-2 text-[10px] text-[#666]">TACTICAL PLAN</div>
             
             {/* TARGET */}
             <div className="mb-8 relative pl-6 border-l-2 border-[#00FF41]">
               <div className="absolute -left-[5px] top-0 w-2 h-2 rounded-full bg-[#00FF41]"></div>
               <div className="text-[10px] text-[#00FF41] mb-1">TARGET PRICE (TAKE PROFIT)</div>
               <div className="text-3xl font-mono text-white">{signal.targetPrice}</div>
             </div>

             {/* ENTRY */}
             <div className="mb-8 relative pl-6 border-l-2 border-dashed border-gray-600">
               <div className="absolute -left-[5px] top-1/2 -translate-y-1/2 w-2 h-2 border border-gray-400 bg-black"></div>
               <div className="text-[10px] text-gray-400 mb-1">ENTRY ZONE</div>
               <div className="text-xl font-mono text-gray-200">{signal.entryZone}</div>
             </div>

             {/* STOP LOSS */}
             <div className="relative pl-6 border-l-2 border-[#FF003C]">
               <div className="absolute -left-[5px] bottom-0 w-2 h-2 rounded-full bg-[#FF003C]"></div>
               <div className="text-[10px] text-[#FF003C] mb-1">INVALIDATION (STOP LOSS)</div>
               <div className="text-2xl font-mono text-white">{signal.stopLoss}</div>
             </div>
           </div>
        </div>

        {/* COLUMN 3: TECHNICAL MATRIX */}
        <div className="bg-[#0a0a0a] border border-[#333] p-6 flex flex-col">
          <h3 className="text-[#666] text-xs font-bold tracking-widest mb-6">TECHNICAL MATRIX</h3>
          
          <div className="space-y-6 flex-1">
            {/* RSI */}
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-xs text-gray-400">RSI (14)</span>
                <span className={`text-xs font-bold ${latest.indicators.rsi > 70 ? 'text-[#FF003C]' : latest.indicators.rsi < 30 ? 'text-[#00FF41]' : 'text-gray-500'}`}>
                  {latest.indicators.rsi.toFixed(2)} [{getRSIState(latest.indicators.rsi)}]
                </span>
              </div>
              <div className="w-full bg-[#111] h-1">
                 <div className="h-full bg-blue-500" style={{ width: `${latest.indicators.rsi}%` }}></div>
              </div>
            </div>

            {/* MACD */}
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-xs text-gray-400">MACD MOMENTUM</span>
                <span className={`text-xs font-bold ${latest.indicators.macd.histogram > 0 ? 'text-[#00FF41]' : 'text-[#FF003C]'}`}>
                  {getMACDState(latest.indicators.macd.histogram)}
                </span>
              </div>
              <div className="flex gap-1 h-8 items-end">
                 {[...Array(10)].map((_, i) => (
                    <div key={i} className={`flex-1 ${i < 5 ? 'bg-[#111]' : latest.indicators.macd.histogram > 0 ? 'bg-[#00FF41]' : 'bg-[#111]'}`} style={{ height: '50%' }}></div>
                 ))}
              </div>
            </div>

            {/* TREND */}
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-xs text-gray-400">EMA Trend (50)</span>
                <span className="text-xs text-white font-mono">{latest.indicators.ema50.toFixed(2)}</span>
              </div>
              <div className={`p-2 text-center text-xs border ${latest.close > latest.indicators.ema50 ? 'border-[#00FF41] text-[#00FF41] bg-[#00FF41]/10' : 'border-[#FF003C] text-[#FF003C] bg-[#FF003C]/10'}`}>
                 PRICE IS {latest.close > latest.indicators.ema50 ? 'ABOVE' : 'BELOW'} AVERAGE
              </div>
            </div>

            <div className="mt-auto pt-6 border-t border-[#333]">
              <button 
                onClick={onAnalyze}
                className="w-full py-3 bg-[#111] hover:bg-[#222] text-xs text-gray-300 border border-[#333] transition-colors"
              >
                REFRESH MATRIX
              </button>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
};
