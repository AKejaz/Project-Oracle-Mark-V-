import React from 'react';
import { NewsItem } from '../types';

interface GlobalIntelProps {
  news: NewsItem[];
  loading: boolean;
  ticker: string;
}

export const GlobalIntel: React.FC<GlobalIntelProps> = ({ news, loading, ticker }) => {
  return (
    <div className="h-full flex flex-col bg-[#050505] border border-[#111]">
      <div className="p-4 border-b border-[#111] flex justify-between items-center">
        <h2 className="text-[#00FF41] text-sm font-bold tracking-widest">GLOBAL INTEL FEED: {ticker}</h2>
        {loading && <div className="text-[10px] text-[#00FF41] animate-pulse">ESTABLISHING UPLINK...</div>}
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {!loading && news.length === 0 && (
          <div className="text-[#333] text-center mt-10 text-xs">NO INTEL FOUND IN SECTOR.</div>
        )}

        {news.map((item, idx) => (
          <a 
            key={idx} 
            href={item.url} 
            target="_blank" 
            rel="noopener noreferrer"
            className="block bg-[#111] border-l-2 hover:bg-[#1a1a1a] transition-colors p-4 group"
            style={{ borderColor: item.sentiment === 'positive' ? '#00FF41' : item.sentiment === 'negative' ? '#FF003C' : '#666' }}
          >
            <div className="flex justify-between items-start mb-2">
               <span className="text-[10px] bg-[#222] text-[#888] px-2 py-0.5 rounded uppercase">{item.source}</span>
               <span className={`text-[10px] font-bold uppercase ${
                 item.sentiment === 'positive' ? 'text-[#00FF41]' : 
                 item.sentiment === 'negative' ? 'text-[#FF003C]' : 'text-gray-400'
               }`}>
                 {item.sentiment}
               </span>
            </div>
            <h3 className="text-gray-200 text-sm font-mono group-hover:text-[#00FF41] transition-colors leading-relaxed">
              {item.title}
            </h3>
            <div className="text-[10px] text-[#444] mt-2 truncate">{item.url}</div>
          </a>
        ))}
      </div>
    </div>
  );
};
