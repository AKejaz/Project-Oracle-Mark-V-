import React from 'react';
import { MarketSignal, SignalType } from '../types';

interface SignalDisplayProps {
  signal: MarketSignal | null;
  loading: boolean;
  onAnalyze: () => void;
}

export const SignalDisplay: React.FC<SignalDisplayProps> = ({ signal, loading, onAnalyze }) => {
  const getSignalColor = (type: SignalType) => {
    switch (type) {
      case SignalType.BUY: return 'text-[#00FF41] border-[#00FF41] shadow-[0_0_15px_#00FF41]';
      case SignalType.SELL: return 'text-[#FF003C] border-[#FF003C] shadow-[0_0_15px_#FF003C]';
      default: return 'text-yellow-400 border-yellow-400 shadow-[0_0_15px_#FACC15]';
    }
  };

  const getBgColor = (type: SignalType) => {
    switch (type) {
        case SignalType.BUY: return 'bg-[#00FF41]/10';
        case SignalType.SELL: return 'bg-[#FF003C]/10';
        default: return 'bg-yellow-400/10';
    }
  }

  return (
    <div className="bg-[#050505] border border-[#111] p-6 rounded-sm relative group overflow-hidden">
      <div className="absolute top-0 right-0 p-2 opacity-50">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1" className="text-[#333]">
          <path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"/>
        </svg>
      </div>

      <h3 className="text-[#666] text-xs font-bold tracking-widest mb-4">DECISION ENGINE</h3>

      {!signal && !loading && (
        <div className="text-center py-8">
          <p className="text-[#333] mb-4 text-sm">AWAITING INPUT STREAM...</p>
          <button 
            onClick={onAnalyze}
            className="px-6 py-2 bg-[#111] text-[#00FF41] border border-[#00FF41] hover:bg-[#00FF41] hover:text-black transition-all text-xs font-bold tracking-widest uppercase neon-border"
          >
            Run Oracle Analysis
          </button>
        </div>
      )}

      {loading && (
        <div className="flex flex-col items-center justify-center py-8 space-y-4">
           <div className="relative w-12 h-12">
             <div className="absolute inset-0 border-t-2 border-[#00FF41] rounded-full animate-spin"></div>
             <div className="absolute inset-2 border-r-2 border-[#00FF41] rounded-full animate-spin reverse"></div>
           </div>
           <div className="text-[#00FF41] text-xs animate-pulse">PROCESSING NEURAL NET...</div>
        </div>
      )}

      {signal && !loading && (
        <div className="animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className={`text-5xl font-black tracking-tighter mb-2 border-2 text-center py-4 rounded ${getSignalColor(signal.type)} ${getBgColor(signal.type)}`}>
            {signal.type}
          </div>
          
          <div className="flex justify-between items-center my-4 px-2">
            <span className="text-xs text-[#666]">CONFIDENCE</span>
            <div className="flex-1 mx-4 h-1 bg-[#111] rounded-full overflow-hidden">
              <div 
                className="h-full bg-current transition-all duration-1000" 
                style={{ width: `${signal.score}%`, backgroundColor: signal.type === SignalType.SELL ? '#FF003C' : '#00FF41' }}
              ></div>
            </div>
            <span className="text-xs font-bold">{signal.score}%</span>
          </div>

          <div className="space-y-2 mt-4">
            {signal.reasoning.map((reason, i) => (
              <div key={i} className="flex items-center gap-2 text-xs text-gray-400">
                <span className={`w-1 h-1 rounded-full ${signal.type === SignalType.SELL ? 'bg-red-500' : 'bg-green-500'}`}></span>
                {reason}
              </div>
            ))}
          </div>
          
          <button 
            onClick={onAnalyze}
            className="w-full mt-6 py-2 border border-[#333] text-[#666] text-xs hover:text-[#00FF41] hover:border-[#00FF41] transition-colors uppercase tracking-wider"
          >
            Re-Calculate
          </button>
        </div>
      )}
    </div>
  );
};
