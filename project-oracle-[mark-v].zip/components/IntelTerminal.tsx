import React from 'react';

interface IntelTerminalProps {
  summary: string;
  ticker: string;
}

export const IntelTerminal: React.FC<IntelTerminalProps> = ({ summary, ticker }) => {
  return (
    <div className="bg-[#050505] border border-[#111] rounded-sm flex flex-col h-full">
      <div className="bg-[#111] p-2 flex justify-between items-center px-4">
         <span className="text-xs font-bold tracking-widest text-[#00FF41]">GLOBAL INTEL FEED</span>
         <div className="flex gap-1">
           <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse"></div>
           <div className="w-2 h-2 rounded-full bg-yellow-500"></div>
           <div className="w-2 h-2 rounded-full bg-green-500"></div>
         </div>
      </div>
      
      <div className="p-4 flex-1 overflow-y-auto font-mono text-xs leading-relaxed text-gray-300">
        <div className="mb-4 text-[#00FF41] opacity-70 border-b border-[#00FF41]/20 pb-2">
          > TARGET: {ticker}<br/>
          > SOURCE: ORACLE_MAIN_NET<br/>
          > ENCRYPTION: VERIFIED
        </div>
        
        {summary ? (
          <div className="typing-effect space-y-4">
             <p>{summary}</p>
             <div className="mt-4 p-2 border border-[#333] bg-[#080808]">
               <div className="text-[10px] text-[#666] mb-1">SENTIMENT ANALYSIS (RSS/VADER)</div>
               <div className="flex justify-between items-center text-[#00FF41]">
                 <span>MARKET MOOD</span>
                 <span>GREED [74/100]</span>
               </div>
             </div>
          </div>
        ) : (
          <div className="text-gray-600 italic">
            Waiting for data stream... <span className="animate-pulse">_</span>
          </div>
        )}
      </div>
    </div>
  );
};
