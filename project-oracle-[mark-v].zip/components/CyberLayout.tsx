import React from 'react';

interface CyberLayoutProps {
  children: React.ReactNode;
}

export const CyberLayout: React.FC<CyberLayoutProps> = ({ children }) => {
  return (
    <div className="relative min-h-screen w-full bg-black text-[#00FF41] selection:bg-[#00FF41] selection:text-black overflow-hidden flex flex-col">
      {/* Scanline Overlay */}
      <div className="scanline pointer-events-none fixed inset-0 z-50"></div>
      
      {/* Header */}
      <header className="border-b border-[#111] bg-[#050505] p-4 flex justify-between items-center z-40 relative">
        <div className="flex items-center gap-4">
          <div className="h-3 w-3 bg-[#00FF41] rounded-full animate-pulse shadow-[0_0_10px_#00FF41]"></div>
          <h1 className="text-2xl font-bold tracking-widest neon-text">PROJECT ORACLE <span className="text-xs align-top opacity-70">[MARK V]</span></h1>
        </div>
        <div className="text-xs text-[#00FF41]/60 font-mono hidden md:block">
          SYS.STATUS: ONLINE // ENCRYPTION: AES-256 // NODE: TOKYO-3
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 flex overflow-hidden relative z-30">
        {children}
      </main>

      {/* Background Grid */}
      <div className="absolute inset-0 z-0 opacity-10" 
           style={{ 
             backgroundImage: 'linear-gradient(#111 1px, transparent 1px), linear-gradient(90deg, #111 1px, transparent 1px)', 
             backgroundSize: '40px 40px' 
           }}>
      </div>
    </div>
  );
};
